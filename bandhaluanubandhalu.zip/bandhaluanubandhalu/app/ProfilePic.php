<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProfilePic extends Model
{
    protected $table = ['profile_pics'];
}
