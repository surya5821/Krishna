<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OtpForPwd extends Model
{
    public $table = 'otp_forpwd';
    
}
