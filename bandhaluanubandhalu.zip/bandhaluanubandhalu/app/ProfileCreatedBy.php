<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProfileCreatedBy extends Model
{
    protected $table = 'profiles_created_by';
}
