<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FamilyDetails extends Model
{
    protected $table = 'family_details';
}
