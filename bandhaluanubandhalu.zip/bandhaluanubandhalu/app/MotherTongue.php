<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MotherTongue extends Model
{
    protected $table = 'mother_tongue';
}
