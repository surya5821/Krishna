<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FaceFair extends Model
{
    protected $table = 'face_fair';
}
