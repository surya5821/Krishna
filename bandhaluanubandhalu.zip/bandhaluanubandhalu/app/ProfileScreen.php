<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProfileScreen extends Model
{
    protected $table = 'profiles_screen';
}
