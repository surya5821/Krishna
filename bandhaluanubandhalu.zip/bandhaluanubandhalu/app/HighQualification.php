<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HighQualification extends Model
{
    protected $table = 'high_qualification';
}
